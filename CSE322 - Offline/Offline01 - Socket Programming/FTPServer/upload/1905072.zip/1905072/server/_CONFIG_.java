package server;

public class _CONFIG_ {
    public static final int MAX_BUFFER_SIZE = 9000000;
    public static final int MIN_CHUNK_SIZE = 1000;
    public static final int MAX_CHUNK_SIZE = 10000;
    public static final int SOCKET_TIMEOUT = 30000;
}
